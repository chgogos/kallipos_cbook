int main(void)
{

    while (x == y)
    {
        do_something1();
        if (a_condition)
        {
            do_something2();
        }
        else
        {
            do_something3();
        }
    }
    do_something4();
}
