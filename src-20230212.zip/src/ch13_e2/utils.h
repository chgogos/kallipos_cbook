#ifndef UTILS_H
#define UTILS_H

void print_message(const char *message);
void print_result(const char *operation, int result);

#endif
