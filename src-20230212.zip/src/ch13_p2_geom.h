typedef struct {
  double x;
  double y;
} point;

double distance(point p1, point p2);
