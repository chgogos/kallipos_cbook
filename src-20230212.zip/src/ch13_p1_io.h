#ifndef CH13_P1_IO_H
#define CH13_P1_IO_H

#include "ch13_p1_utility.h"

#define MAX_CITIES 1000

void read_cities(const char *filename, geo_city *cities, int *num_records);

#endif
