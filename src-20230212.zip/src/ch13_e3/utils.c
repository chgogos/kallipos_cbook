#include "utils.h"
#include <stdio.h>

void util_function(void) {
    printf("Utility function.\n");
}
