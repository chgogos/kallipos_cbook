#include <stdio.h>

int main() {
  char greeting[] = {'h', 'e', 'l', 'l', 'o'};
  printf("%s", greeting);
  return 0;
}
