#include <stdio.h>

int main(void) {
  printf("15 / 7 = %d, 15 %% 7 = %d\n", 15 / 7, 15 % 7);
  printf("7 / 15 = %d, 7 %% 15 = %d\n", 7 / 15, 7 % 15);
  printf("15.0 / 7.0 = %.2f\n", 15.0 / 7.0);
  printf("15 / 7.0 = %.2f\n", 15 / 7.0);
  printf("15.0 / 7 = %.2f\n", 15.0 / 7);
  return 0;
}
