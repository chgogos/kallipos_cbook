#ifndef CH12_P10_UTILITY_H
#define CH12_P10_UTILITY_H

int add_numbers(int a, int b);

#endif
