void foo(int a);
