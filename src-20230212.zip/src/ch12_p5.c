#include <stdio.h>

#define CAT(x, y) x##y

int main(void) {
  int CAT(x, 0) = CAT(1, e6);
  double CAT(z, 99) = CAT(2, e6);
  printf("%d\n", x0);
  printf("%f\n", z99);
}
