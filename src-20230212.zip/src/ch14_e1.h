#ifndef CH14_E1_H
#define CH14_E1_H

#include <stdbool.h>

bool is_valid_password(const char *pwd);

#endif
