#ifndef CH14_E3_ARRAY_H
#define CH14_E3_ARRAY_H

int find_index(int *array, int size, int element);

#endif // CH14_E3_ARRAY_H
